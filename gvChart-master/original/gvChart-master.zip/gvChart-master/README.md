gvChart
=======

jQuery plugin for generating Google Charts from well-formed tables

For more info check my blog: http://www.ivellios.toron.pl/technikalia/2010/06/22/gvchart-plugin-jquery-with-google-charts/